import pytest
from app import create_app
from app.extensions import db
from config import TestingConfig


@pytest.fixture
def app():
    app = create_app(TestingConfig)
    yield app


@pytest.fixture
def client(app):
    return app.test_client()


def register(client, username="testuser", email="test@example.com", password="password123"):
    return client.post(
        "/register",
        data={"username": username, "email": email, "password": password},
        follow_redirects=True,
    )


def test_index_loads(client):
    resp = client.get("/")
    assert resp.status_code == 200


def test_register_and_redirect_to_dashboard(client):
    resp = register(client)
    assert resp.status_code == 200
    assert b"Your Dashboard" in resp.data


def test_duplicate_username_rejected(client):
    register(client)
    client.get("/logout")  # must log out first - register() redirects logged-in users to dashboard
    resp = register(client, email="other@example.com")
    assert b"already taken" in resp.data


def test_add_entry_requires_login(client):
    resp = client.post("/entries/add", data={"category": "ctf", "title": "Test"})
    assert resp.status_code in (302, 401)


def test_add_entry_rejects_invalid_link(client):
    register(client)
    resp = client.post(
        "/entries/add",
        data={"category": "ctf", "title": "HTB Box", "link": "javascript:alert(1)"},
        follow_redirects=True,
    )
    assert b"must be a valid http" in resp.data


def test_public_portfolio_visible_without_login(client):
    register(client)
    resp = client.get("/u/testuser")
    assert resp.status_code == 200
