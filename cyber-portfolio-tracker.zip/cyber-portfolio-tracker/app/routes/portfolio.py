from datetime import datetime
from urllib.parse import urlparse

from flask import Blueprint, render_template, redirect, url_for, request, flash, abort
from flask_login import login_required, current_user

from app.extensions import db
from app.models import User, PortfolioEntry, VALID_CATEGORIES

portfolio_bp = Blueprint("portfolio", __name__)


def _safe_url(raw_url: str) -> str | None:
    """Only allow http/https links to prevent javascript: URI injection
    when the link is later rendered as an <a href>."""
    raw_url = (raw_url or "").strip()
    if not raw_url:
        return None
    parsed = urlparse(raw_url)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        return None
    return raw_url


@portfolio_bp.route("/")
def index():
    return render_template("index.html")


@portfolio_bp.route("/dashboard")
@login_required
def dashboard():
    entries = (
        PortfolioEntry.query.filter_by(user_id=current_user.id)
        .order_by(PortfolioEntry.created_at.desc())
        .all()
    )
    counts = {cat: 0 for cat in VALID_CATEGORIES}
    for e in entries:
        counts[e.category] = counts.get(e.category, 0) + 1

    return render_template(
        "dashboard.html", entries=entries, counts=counts, categories=VALID_CATEGORIES
    )


@portfolio_bp.route("/entries/add", methods=["POST"])
@login_required
def add_entry():
    category = request.form.get("category", "")
    title = request.form.get("title", "").strip()
    description = request.form.get("description", "").strip()
    link = request.form.get("link", "").strip()
    date_str = request.form.get("date_completed", "").strip()

    if category not in VALID_CATEGORIES:
        flash("Invalid category.", "error")
        return redirect(url_for("portfolio.dashboard"))

    if not title or len(title) > 120:
        flash("Title is required and must be under 120 characters.", "error")
        return redirect(url_for("portfolio.dashboard"))

    safe_link = _safe_url(link)
    if link and safe_link is None:
        flash("Link must be a valid http:// or https:// URL.", "error")
        return redirect(url_for("portfolio.dashboard"))

    date_completed = None
    if date_str:
        try:
            date_completed = datetime.strptime(date_str, "%Y-%m-%d").date()
        except ValueError:
            flash("Invalid date format.", "error")
            return redirect(url_for("portfolio.dashboard"))

    entry = PortfolioEntry(
        user_id=current_user.id,
        category=category,
        title=title,
        description=description[:1000],
        link=safe_link,
        date_completed=date_completed,
    )
    db.session.add(entry)
    db.session.commit()
    flash("Entry added.", "success")
    return redirect(url_for("portfolio.dashboard"))


@portfolio_bp.route("/entries/<int:entry_id>/delete", methods=["POST"])
@login_required
def delete_entry(entry_id):
    entry = db.session.get(PortfolioEntry, entry_id)
    if entry is None:
        abort(404)
    if entry.user_id != current_user.id:
        abort(403)

    db.session.delete(entry)
    db.session.commit()
    flash("Entry deleted.", "info")
    return redirect(url_for("portfolio.dashboard"))


@portfolio_bp.route("/u/<username>")
def public_portfolio(username):
    user = User.query.filter_by(username=username).first_or_404()
    if not user.is_public:
        abort(404)

    entries = (
        PortfolioEntry.query.filter_by(user_id=user.id)
        .order_by(PortfolioEntry.date_completed.desc().nullslast())
        .all()
    )
    return render_template("portfolio_public.html", profile_user=user, entries=entries)
