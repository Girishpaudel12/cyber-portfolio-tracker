from flask import Blueprint, jsonify
from flask_login import login_required, current_user

from app.models import PortfolioEntry

api_bp = Blueprint("api", __name__)


@api_bp.route("/entries")
@login_required
def list_entries():
    entries = PortfolioEntry.query.filter_by(user_id=current_user.id).all()
    return jsonify(
        [
            {
                "id": e.id,
                "category": e.category,
                "title": e.title,
                "description": e.description,
                "link": e.link,
                "date_completed": e.date_completed.isoformat() if e.date_completed else None,
            }
            for e in entries
        ]
    )
