document.addEventListener("DOMContentLoaded", () => {
  // Category filter buttons (dashboard + public page)
  const filterButtons = document.querySelectorAll(".filter-btn");
  const cards = document.querySelectorAll(".entry-card");

  filterButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      filterButtons.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");

      const filter = btn.dataset.filter;
      cards.forEach((card) => {
        const show = filter === "all" || card.dataset.category === filter;
        card.style.display = show ? "" : "none";
      });
    });
  });

  // Confirm before deleting an entry
  document.querySelectorAll(".delete-form").forEach((form) => {
    form.addEventListener("submit", (e) => {
      if (!confirm("Delete this entry? This can't be undone.")) {
        e.preventDefault();
      }
    });
  });
});
