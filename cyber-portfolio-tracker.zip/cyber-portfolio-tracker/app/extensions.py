"""
Centralized Flask extension instances.

Kept separate from app/__init__.py to avoid circular imports between
models, routes, and the app factory.
"""
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager

db = SQLAlchemy()
login_manager = LoginManager()
login_manager.login_view = "auth.login"
login_manager.login_message_category = "info"
